<?php
/*
Plugin Name: Site Optimizer
Description: Security, Backup, Performance Optimization, and SEO in one plugin.
Version: 1.0
Author: Your Name
*/

define('SO_PATH', plugin_dir_path(__FILE__));
define('SO_URL', plugin_dir_url(__FILE__));

require_once SO_PATH . 'includes/admin-panel.php';

// Conditional Features
$options = get_option('so_settings');

if (!is_admin()) {
    if (!empty($options['enable_firewall'])) {
        require_once SO_PATH . 'includes/firewall.php';
    }

    if (!empty($options['enable_optimization'])) {
        require_once SO_PATH . 'includes/optimization.php';
    }

    if (!empty($options['enable_seo'])) {
        require_once SO_PATH . 'includes/seo.php';
    }
}

if (!empty($options['enable_backup']) && is_admin()) {
    require_once SO_PATH . 'includes/backup.php';
}
