<?php
// Simple SEO Tags
add_action('wp_head', function() {
    echo '<meta name="description" content="My awesome site">';
});

add_action('init', function() {
    file_put_contents(ABSPATH . 'robots.txt', "User-agent: *\nDisallow:\nSitemap: " . home_url('/sitemap.xml'));
});

add_action('init', function() {
    $sitemap = '<?xml version="1.0" encoding="UTF-8"?>';
    $sitemap .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
    $posts = get_posts(['numberposts' => -1, 'post_type' => 'post', 'post_status' => 'publish']);
    foreach ($posts as $post) {
        $sitemap .= '<url><loc>' . get_permalink($post->ID) . '</loc></url>';
    }
    $sitemap .= '</urlset>';
    file_put_contents(ABSPATH . 'sitemap.xml', $sitemap);
});
