<?php
// Optimization: Minify HTML output
defined('ABSPATH') || exit;

ob_start(function ($buffer) {
    return preg_replace(['/\s+/','/<!--.*?-->/'], [' ', ''], $buffer);
});
