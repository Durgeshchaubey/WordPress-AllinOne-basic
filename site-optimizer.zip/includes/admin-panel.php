<?php
add_action('admin_menu', 'so_add_admin_menu');
add_action('admin_init', 'so_settings_init');

function so_add_admin_menu() {
    add_options_page('Site Optimizer', 'Site Optimizer', 'manage_options', 'site_optimizer', 'so_options_page');
}

function so_settings_init() {
    register_setting('pluginPage', 'so_settings');

    add_settings_section('so_section', __('Toggle Features', 'wordpress'), null, 'pluginPage');

    $features = [
        'enable_firewall' => 'Enable Firewall',
        'enable_backup' => 'Enable Backup',
        'enable_optimization' => 'Enable Optimization',
        'enable_seo' => 'Enable SEO Features'
    ];

    foreach ($features as $key => $label) {
        add_settings_field($key, __($label, 'wordpress'), function() use ($key) {
            $options = get_option('so_settings');
            echo '<input type="checkbox" name="so_settings[' . $key . ']" ' . checked($options[$key] ?? '', 'on', false) . ' />';
        }, 'pluginPage', 'so_section');
    }
}

function so_options_page() {
    ?>
    <form action="options.php" method="post">
        <h2>Site Optimizer</h2>
        <?php
        settings_fields('pluginPage');
        do_settings_sections('pluginPage');
        submit_button();
        ?>
    </form>
    <?php
}
