<?php
// Simple Backup Button
add_action('admin_menu', function() {
    add_submenu_page(null, 'Backup Now', 'Backup Now', 'manage_options', 'so_backup_now', 'so_run_backup');
});

function so_run_backup() {
    // Basic backup stub
    echo 'Backup triggered';
}
