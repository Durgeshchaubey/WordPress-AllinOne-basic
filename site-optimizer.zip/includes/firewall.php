<?php
// Basic Firewall
add_action('init', function() {
    if (strpos($_SERVER['REQUEST_URI'], '../') !== false) {
        wp_die('Blocked for security');
    }
});
